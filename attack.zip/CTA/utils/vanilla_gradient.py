import torch
import numpy as np

from attack.CTA.utils.saliency_mask import SaliencyMask


class VanillaGradient(SaliencyMask):
    def __init__(self, model):
        super(VanillaGradient, self).__init__(model)

    def get_mask(self, image_tensor, target_class=None,set_size=2):
        image_tensor = image_tensor.clone()
        image_tensor.requires_grad = True
        image_tensor.retain_grad()

        logits,_,_ = self.model(image_tensor)
        target = torch.zeros_like(logits)
        #target[0][target_class if target_class else logits.topk(1, dim=1)[1]] = 1
        #target[0][target_class if target_class else logits.topk(1, dim=1)[1]] = 1
        for j in range(set_size):
            target[j][target_class if target_class else logits.topk(1, dim=1)[1]] = 1
        #print(target)
        self.model.zero_grad()
        logits.backward(target)
        return np.moveaxis(image_tensor.grad.detach().cpu().numpy(), 0, -1)

    def get_smoothed_mask(self, image_tensor, target_class=None, samples=25, std=0.15, process=lambda x: x**2):
        std = std * (torch.max(image_tensor) - torch.min(image_tensor)).detach().cpu().numpy()

        batch, channels, width, height = image_tensor.size()
        grad_sum = np.zeros((width, height, channels))
        for sample in range(samples):
            noise = torch.empty(image_tensor.size()).normal_(0, std).to(image_tensor.device)
            noise_image = image_tensor + noise
            grad_sum += process(self.get_mask(noise_image, target_class))
        return grad_sum / samples

    @staticmethod
    def apply_region(mask, region):
        return mask * region[..., np.newaxis]